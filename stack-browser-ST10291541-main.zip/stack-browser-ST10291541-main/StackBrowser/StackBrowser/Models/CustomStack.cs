﻿namespace StackBrowser.Models
{
    public class CustomStack
    {
        private List<string> items = new List<string>();

        public void Push(string item) => items.Add(item);

        public string Pop()
        {
            if (IsEmpty())
                throw new InvalidOperationException("Stack is empty!");
            string value = items[^1];
            items.RemoveAt(items.Count - 1);
            return value;
        }

        public string Peek()
        {
            if (IsEmpty())
                throw new InvalidOperationException("Stack is empty!");
            return items[^1];
        }

        public bool IsEmpty() => items.Count == 0;

        public int Count() => items.Count;

        public List<string> GetAll() => new List<string>(items);
    }
}
