﻿using Microsoft.AspNetCore.Mvc;
using StackBrowser.Models;
using System.Text.Json;

namespace StackBrowser.Controllers
{
    public class BrowserController : Controller
    {
        private const string HistoryKey = "HistoryStack";
        private const string CurrentPageKey = "CurrentPage";

        private CustomStack? GetHistory()
        {
            var json = HttpContext.Session.GetString(HistoryKey);
            return string.IsNullOrEmpty(json)
                ? new CustomStack()
                : JsonSerializer.Deserialize<CustomStack>(json);
        }

        private void SaveHistory(CustomStack history)
        {
            HttpContext.Session.SetString(HistoryKey, JsonSerializer.Serialize(history));
        }

        public IActionResult Index()
        {
            string currentPage = HttpContext.Session.GetString(CurrentPageKey);
            return View("Index", currentPage);
        }

        [HttpPost]
        public IActionResult Visit(string url)
        {
            var history = GetHistory();
            string currentPage = HttpContext.Session.GetString(CurrentPageKey);

            if (!string.IsNullOrEmpty(currentPage))
                history.Push(currentPage);

            HttpContext.Session.SetString(CurrentPageKey, url);
            SaveHistory(history);

            return RedirectToAction("Index");
        }

        public IActionResult Back()
        {
            var history = GetHistory();
            if (!history.IsEmpty())
            {
                string prevPage = history.Pop();
                HttpContext.Session.SetString(CurrentPageKey, prevPage);
                SaveHistory(history);
            }
            return RedirectToAction("Index");
        }

        public IActionResult History()
        {
            var history = GetHistory();
            return View(history.GetAll());
        }
    }
}
